DAYMARK — Days Since inspired web app

Open index.html in your browser, or upload the folder to GitHub Pages, Netlify, or any static host.

Features: multiple persistent counters, milestone badges, progress bars, category filters, four themes, edit/reset/delete, share, JSON backup and restore.

Data is stored in localStorage for the specific browser and origin. Export backups to preserve data when moving devices or clearing browser storage.
